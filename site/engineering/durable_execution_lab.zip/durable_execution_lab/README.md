# 持久执行与科学验收：离线教学实验

本包是纯 Python 标准库练习，需要 Python 3.10 或更高版本。它**模拟本地外部调度器**，没有模型调用、真实 HPC/Slurm、PDB/mmCIF 解析或真实生物学分析。这里的 `accepted` 仅表示合成几何练习通过当前教学判据。

## 你要观察什么

同一个逻辑操作的 `operation_key` 来自固定任务内容。`Control` 在调用外部系统前，先保存提交意图，再持久化 `SUBMITTING`。模拟调度器创建并提交本地作业记录，然后故意丢失回执。关闭所有连接、建立新连接后，恢复程序根据关联键查找原作业，确认唯一候选后继续观察与验证；不重新提交。

控制账本和模拟调度器使用**两个 SQLite 文件**，没有把它们放进同一个事务。调度器的关联键也**没有唯一约束**：直接向它提交同一个键两次，确实会创建两个作业。这是练习的重要条件。

| 层次 | 问什么 | 示例状态 |
|---|---|---|
| 提交 | 外部是否接收，能否唯一关联？ | `INTENT / SUBMITTING / UNKNOWN / BOUND` |
| 执行 | 已确认作业是否成功退出？ | `NOT_OBSERVED / SUCCEEDED / FAILED` |
| 验证 | 结果是否符合某版本的判据？ | `NOT_VALIDATED / PASSED / REJECTED` |

这里没有模拟所有生产状态；真实系统还需要排队、运行、超时、取消、清理、权限与资源管理。

## 运行三个场景

进入本目录后运行，三种场景使用不同输出目录：

```bash
python3 durable_demo.py demo-good
python3 durable_demo.py demo-rejected --bad-result
python3 durable_demo.py demo-ambiguous --ambiguous
python3 -m unittest -v
```

每次运行在指定目录生成：

- `control.sqlite`：任务意图、提交状态、事件和追加保存的验证记录。
- `scheduler.sqlite`：独立模拟调度器的作业记录。
- `events.json`：便于直接打开阅读的事件、作业与验证清单。

`demo-good` 应有 **1 个作业**，出现 `ACK_LOST → JOB_RECONCILED → EXECUTION_OBSERVED → VALIDATION_RECORDED`；最终执行与验证均通过。

`demo-rejected` 的进程退出状态仍成功，但故意返回错误距离。两个点是合成的 3–4–5 三角形，验证应拒绝结果，最终 `execution=SUCCEEDED`、`validation=REJECTED`、`accepted=false`。

`demo-ambiguous` 故意制造 **2 个同键作业**。恢复不能选一个猜答案，也不能重新提交，应保留 `UNKNOWN`，并让 `accepted=false`。零候选也保留 `UNKNOWN`；真实系统中的记录可能延迟或不可见，单次没查到不等于可以安全重提。

重复运行同一输出目录会复用原意图，不额外创建作业；唯一关联场景会追加新的验证历史。故障开关只影响首次提交，要比较新故障请使用新的输出目录。

## 阅读代码的顺序

1. `intent()`：内容身份怎样确定，提交意图怎样持久化。
2. `submit()`：为什么必须在外部调用前提交 `SUBMITTING`；重复投递怎样被拒绝。
3. `LocalScheduler.submit()`：外部记录已经存在，客户端却没有回执。
4. `reconcile()`：唯一候选才绑定；这个函数从不调用 `submit()`。
5. `observe()` 与 `validate()`：退出成功、产物观察和判据通过分别保存。
6. `summary()`：只有已确认作业、成功执行和当前验证通过同时成立，教学结果才被接受。

`geometry-v1` 与 `geometry-v2` 使用不同的绝对误差容限。新验证追加记录，不覆盖旧版本。当前教学接受规则固定为 `geometry-v2`，不能通过最后重跑宽松的 `v1` 来覆盖 `v2` 的拒绝。测试注入处于两种容差之间的结果，确认两版判定可以同时追溯。真实系统应在任务合同中固定要求的验证版本与规则；更换规则需显式修订和重验。

## 测试所证明与未证明的事

8 项测试覆盖回执丢失后的新连接恢复、重复恢复/投递、不唯一候选、零候选、进程成功而结果被拒绝、验证版本历史、旧规则不能覆盖当前拒绝，以及在更新 `UNKNOWN` 之前崩溃的持久状态。

这个练习验证本地状态转换，**不证明真实调度器具有 exactly-once 提交能力**。一个关联键只提供身份，不能自动阻止外部重复；真实 Slurm 也不能仅凭作业名推断去重保证。真实接入需要确认身份、查询可见性、记账延迟、并发提交控制、后端保证与人工介入边界。

模拟工具与验证器均使用标准库几何计算，本例重点是控制状态和判定分离，不构成独立科学验证实现。生产验证还应使用任务适配的独立参考、不变性质、对象选择检查和领域规则。CLI 中“重启”通过关闭并重开数据库连接模拟，并没有测试断电、磁盘损坏、网络分区或多节点高并发。

## 对照官方资料

- [LangGraph Checkpointers](https://docs.langchain.com/oss/python/langgraph/checkpointers)：检查点与重放保存的是程序状态；旧检查点之后的调用可能重新执行。
- [Temporal Activities](https://docs.temporal.io/activities)：活动重试需要考虑幂等与外部副作用。
- [Slurm sbatch](https://slurm.schedmd.com/sbatch.html)：提交接收和 Job ID 不代表计算已经执行完成。
- [Slurm sacct](https://slurm.schedmd.com/sacct.html)：历史作业核对依赖实际启用的记账与访问设置。
