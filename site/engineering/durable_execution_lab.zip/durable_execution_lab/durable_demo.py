"""Offline teaching model; no LLM, real scheduler, or PDB parsing."""
import argparse
import hashlib
import json
import math
import sqlite3
from datetime import datetime, timezone
from pathlib import Path


def encode(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


class LostAcknowledgement(Exception):
    pass


class Database:
    def __init__(self, path):
        self.db = sqlite3.connect(path, timeout=5)
        self.db.row_factory = sqlite3.Row

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.db.close()


class LocalScheduler(Database):
    """Separate persistence, deliberately NO unique constraint on operation key."""
    def __init__(self, path):
        super().__init__(path)
        self.db.execute("""CREATE TABLE IF NOT EXISTS jobs (
            job_id INTEGER PRIMARY KEY, operation_key TEXT NOT NULL,
            exit_code INTEGER NOT NULL, result TEXT NOT NULL)""")
        self.db.commit()

    def submit(self, key, intent, *, lose_ack=False, bad_result=False):
        # Instant local fixture: external execution already finished successfully.
        distance = math.dist(*intent["points"]) + (1.0 if bad_result else 0.0)
        result = {"distance": distance, "unit": intent["unit"]}
        with self.db:
            cursor = self.db.execute(
                "INSERT INTO jobs(operation_key,exit_code,result) VALUES(?,0,?)",
                (key, encode(result)))
        if lose_ack:
            raise LostAcknowledgement("job committed; acknowledgement was lost")
        return cursor.lastrowid

    def find(self, key):
        return [dict(r) for r in self.db.execute(
            "SELECT * FROM jobs WHERE operation_key=? ORDER BY job_id", (key,))]

    def job(self, job_id):
        row = self.db.execute("SELECT * FROM jobs WHERE job_id=?", (job_id,)).fetchone()
        if row is None:
            raise LookupError("unknown local job")
        return dict(row)


class Control(Database):
    VALIDATORS = {"geometry-v1": 1e-6, "geometry-v2": 1e-9}
    ACTIVE_VALIDATOR = "geometry-v2"  # A fixed teaching acceptance policy.

    def __init__(self, path):
        super().__init__(path)
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS operations (
          operation_key TEXT PRIMARY KEY, intent TEXT NOT NULL,
          phase TEXT NOT NULL, job_id INTEGER, execution TEXT NOT NULL,
          result TEXT);
        CREATE TABLE IF NOT EXISTS events (
          seq INTEGER PRIMARY KEY, operation_key TEXT, kind TEXT,
          detail TEXT, created_at TEXT);
        CREATE TABLE IF NOT EXISTS validations (
          validation_id INTEGER PRIMARY KEY, operation_key TEXT NOT NULL,
          job_id INTEGER NOT NULL, version TEXT NOT NULL, policy TEXT NOT NULL,
          verdict TEXT NOT NULL, detail TEXT NOT NULL);
        """)

    def event(self, key, kind, detail):
        self.db.execute("INSERT INTO events VALUES(NULL,?,?,?,?)",
                        (key, kind, encode(detail), datetime.now(timezone.utc).isoformat()))

    def operation(self, key):
        row = self.db.execute("SELECT * FROM operations WHERE operation_key=?", (key,)).fetchone()
        if row is None:
            raise LookupError("unknown operation")
        return dict(row)

    def intent(self, value):
        if value.get("tool") != "synthetic_distance" or value.get("unit") != "angstrom":
            raise ValueError("only the declared synthetic fixture is supported")
        points = value.get("points")
        if not isinstance(points, list) or len(points) != 2 or any(
            not isinstance(p, list) or len(p) != 3 or any(
                type(v) not in (int, float) or not math.isfinite(v) for v in p) for p in points
        ):
            raise ValueError("expected two finite three-dimensional points")
        payload = encode(value)
        key = hashlib.sha256(payload.encode()).hexdigest()
        with self.db:
            c = self.db.execute("INSERT OR IGNORE INTO operations VALUES(?,?,'INTENT',NULL,'NOT_OBSERVED',NULL)",
                                (key, payload))
            if c.rowcount:
                self.event(key, "INTENT_RECORDED", {"intent": value})
        return key

    def submit(self, scheduler, key, **faults):
        # Commit BEFORE the external call; a crash leaves an uncertain operation.
        with self.db:
            c = self.db.execute("UPDATE operations SET phase='SUBMITTING' WHERE operation_key=? AND phase='INTENT'", (key,))
            if not c.rowcount:
                return False
            self.event(key, "SUBMISSION_STARTED", {})
        try:
            job_id = scheduler.submit(key, json.loads(self.operation(key)["intent"]), **faults)
        except LostAcknowledgement:
            with self.db:
                self.db.execute("UPDATE operations SET phase='UNKNOWN' WHERE operation_key=?", (key,))
                self.event(key, "ACK_LOST", {"action": "reconcile; never blindly resubmit"})
        else:
            with self.db:
                self.db.execute("UPDATE operations SET phase='BOUND',job_id=? WHERE operation_key=?", (job_id, key))
                self.event(key, "ACK_RECEIVED", {"job_id": job_id})
        return True

    def reconcile(self, scheduler, key):
        self.operation(key)
        candidates = scheduler.find(key)
        with self.db:
            if len(candidates) == 1:
                job_id = candidates[0]["job_id"]
                self.db.execute("UPDATE operations SET phase='BOUND',job_id=? WHERE operation_key=?", (job_id, key))
                self.event(key, "JOB_RECONCILED", {"job_id": job_id})
            else:
                self.db.execute("UPDATE operations SET phase='UNKNOWN',job_id=NULL WHERE operation_key=?", (key,))
                self.event(key, "RECONCILIATION_UNRESOLVED", {"candidate_count": len(candidates)})
        return len(candidates)  # This method never calls submit().

    def observe(self, scheduler, key):
        operation = self.operation(key)
        if operation["phase"] != "BOUND":
            raise ValueError("cannot observe an unconfirmed job")
        job = scheduler.job(operation["job_id"])
        if job["operation_key"] != key:
            raise ValueError("job identity mismatch")
        execution = "SUCCEEDED" if job["exit_code"] == 0 else "FAILED"
        with self.db:
            self.db.execute("UPDATE operations SET execution=?,result=? WHERE operation_key=?", (execution, job["result"], key))
            self.event(key, "EXECUTION_OBSERVED", {"execution": execution, "job_id": job["job_id"]})

    def validate(self, key, version):
        operation = self.operation(key)
        if operation["phase"] != "BOUND" or operation["execution"] != "SUCCEEDED":
            raise ValueError("a confirmed successful execution is required")
        tolerance = self.VALIDATORS[version]
        intent, result = json.loads(operation["intent"]), json.loads(operation["result"])
        reference = math.dist(*intent["points"])
        measured = result.get("distance")
        passed = (type(measured) in (int, float) and math.isfinite(measured)
                  and result.get("unit") == intent["unit"]
                  and abs(measured - reference) <= tolerance)
        detail = {"reference": reference, "measured": measured, "synthetic_fixture": True}
        with self.db:
            c = self.db.execute("INSERT INTO validations VALUES(NULL,?,?,?,?,?,?)",
                (key, operation["job_id"], version, encode({"absolute_tolerance": tolerance}),
                 "PASSED" if passed else "REJECTED", encode(detail)))
            self.event(key, "VALIDATION_RECORDED", {"validation_id": c.lastrowid, "version": version, "passed": passed})
        return passed

    def summary(self, key):
        op = self.operation(key)
        latest = self.db.execute("SELECT * FROM validations WHERE operation_key=? AND job_id=? AND version=? ORDER BY validation_id DESC LIMIT 1", (key, op["job_id"], self.ACTIVE_VALIDATOR)).fetchone()
        verdict = latest["verdict"] if latest else "NOT_VALIDATED"
        return {"operation_key": key, "submission": op["phase"], "job_id": op["job_id"],
                "execution": op["execution"], "validation": verdict, "required_validator": self.ACTIVE_VALIDATOR,
                "accepted": op["phase"] == "BOUND" and op["execution"] == "SUCCEEDED" and verdict == "PASSED"}

    def export(self, scheduler, key):
        result = {"scope": "offline synthetic teaching model; no real HPC/LLM/PDB analysis",
                  "summary": self.summary(key), "scheduler_jobs": scheduler.find(key)}
        for table in ("operations", "events", "validations"):
            result[table] = [dict(r) for r in self.db.execute(f"SELECT * FROM {table} WHERE operation_key=?", (key,))]
        return result


FIXTURE = {"tool": "synthetic_distance", "points": [[0, 0, 0], [3, 4, 0]], "unit": "angstrom"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("--bad-result", action="store_true")
    parser.add_argument("--ambiguous", action="store_true")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    control_path, scheduler_path = args.output / "control.sqlite", args.output / "scheduler.sqlite"
    with Control(control_path) as control, LocalScheduler(scheduler_path) as scheduler:
        key = control.intent(FIXTURE)
        submitted = control.submit(scheduler, key, lose_ack=True, bad_result=args.bad_result)
        if args.ambiguous and submitted:
            scheduler.submit(key, FIXTURE)  # Deliberately inject a second candidate.
    # New connections simulate process restart. Neither open connection survives.
    with Control(control_path) as control, LocalScheduler(scheduler_path) as scheduler:
        if control.reconcile(scheduler, key) == 1:
            control.observe(scheduler, key)
            for version in control.VALIDATORS:
                control.validate(key, version)
        report = control.export(scheduler, key)
    (args.output / "events.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report["summary"], indent=2))


if __name__ == "__main__":
    main()
