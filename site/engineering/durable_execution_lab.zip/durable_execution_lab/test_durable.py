import json
import tempfile
import unittest
from pathlib import Path

from durable_demo import Control, FIXTURE, LocalScheduler


class DurableExecutionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        root = Path(self.temp.name)
        self.control_path, self.scheduler_path = root / "control.sqlite", root / "scheduler.sqlite"

    def tearDown(self):
        self.temp.cleanup()

    def lose_ack(self, **faults):
        with Control(self.control_path) as control, LocalScheduler(self.scheduler_path) as scheduler:
            key = control.intent(FIXTURE)
            control.submit(scheduler, key, lose_ack=True, **faults)
            self.assertEqual(control.operation(key)["phase"], "UNKNOWN")
            self.assertIsNone(control.operation(key)["job_id"])
            self.assertEqual(len(scheduler.find(key)), 1)
        return key

    def test_lost_ack_recovered_after_reopening_both_databases(self):
        key = self.lose_ack()
        with Control(self.control_path) as control, LocalScheduler(self.scheduler_path) as scheduler:
            original_job = scheduler.find(key)[0]["job_id"]
            self.assertEqual(control.reconcile(scheduler, key), 1)
            self.assertEqual(control.operation(key)["job_id"], original_job)
            self.assertEqual(control.operation(key)["phase"], "BOUND")
            self.assertEqual(len(scheduler.find(key)), 1)

    def test_repeated_recovery_and_delivery_do_not_create_another_job(self):
        key = self.lose_ack()
        with Control(self.control_path) as control, LocalScheduler(self.scheduler_path) as scheduler:
            for _ in range(3):
                self.assertEqual(control.intent(dict(FIXTURE)), key)
                control.reconcile(scheduler, key)
                self.assertFalse(control.submit(scheduler, key))
            self.assertEqual(len(scheduler.find(key)), 1)

    def test_ambiguous_candidates_remain_unknown_without_resubmission(self):
        key = self.lose_ack()
        with Control(self.control_path) as control, LocalScheduler(self.scheduler_path) as scheduler:
            scheduler.submit(key, FIXTURE)  # External system permits a duplicate.
            self.assertEqual(control.reconcile(scheduler, key), 2)
            self.assertEqual(control.summary(key)["submission"], "UNKNOWN")
            self.assertFalse(control.submit(scheduler, key))
            self.assertFalse(control.summary(key)["accepted"])
            with self.assertRaises(ValueError):
                control.observe(scheduler, key)
            self.assertEqual(len(scheduler.find(key)), 2)

    def test_no_visible_candidate_is_not_proof_that_resubmission_is_safe(self):
        with Control(self.control_path) as control, LocalScheduler(self.scheduler_path) as scheduler:
            key = control.intent(FIXTURE)
            self.assertEqual(control.reconcile(scheduler, key), 0)
            self.assertEqual(control.operation(key)["phase"], "UNKNOWN")
            self.assertFalse(control.submit(scheduler, key))
            self.assertEqual(scheduler.find(key), [])

    def test_successful_process_with_bad_result_is_rejected(self):
        key = self.lose_ack(bad_result=True)
        with Control(self.control_path) as control, LocalScheduler(self.scheduler_path) as scheduler:
            control.reconcile(scheduler, key)
            control.observe(scheduler, key)
            self.assertFalse(control.validate(key, control.ACTIVE_VALIDATOR))
            summary = control.summary(key)
            self.assertEqual(summary["execution"], "SUCCEEDED")
            self.assertEqual(summary["validation"], "REJECTED")
            self.assertFalse(summary["accepted"])

    def test_new_validation_policy_preserves_previous_verdict(self):
        key = self.lose_ack()
        with Control(self.control_path) as control, LocalScheduler(self.scheduler_path) as scheduler:
            # Deliberately inject a boundary result before collection.
            result = json.dumps({"distance": 5 + 2e-7, "unit": "angstrom"})
            with scheduler.db:
                scheduler.db.execute("UPDATE jobs SET result=? WHERE operation_key=?", (result, key))
            control.reconcile(scheduler, key)
            control.observe(scheduler, key)
            self.assertTrue(control.validate(key, "geometry-v1"))
            self.assertFalse(control.validate(key, "geometry-v2"))
            records = control.export(scheduler, key)["validations"]
            self.assertEqual([(r["version"], r["verdict"]) for r in records],
                             [("geometry-v1", "PASSED"), ("geometry-v2", "REJECTED")])
            self.assertNotEqual(records[0]["policy"], records[1]["policy"])
            self.assertFalse(control.summary(key)["accepted"])

    def test_crash_before_unknown_update_can_still_reconcile(self):
        with Control(self.control_path) as control, LocalScheduler(self.scheduler_path) as scheduler:
            key = control.intent(FIXTURE)
            with control.db:
                control.db.execute("UPDATE operations SET phase='SUBMITTING' WHERE operation_key=?", (key,))
            scheduler.submit(key, FIXTURE)
        # Equivalent persisted state to a crash before acknowledgement handling.
        with Control(self.control_path) as control, LocalScheduler(self.scheduler_path) as scheduler:
            self.assertFalse(control.submit(scheduler, key))
            self.assertEqual(control.reconcile(scheduler, key), 1)
            self.assertEqual(len(scheduler.find(key)), 1)

    def test_older_validator_cannot_override_current_rejection(self):
        key = self.lose_ack()
        with Control(self.control_path) as control, LocalScheduler(self.scheduler_path) as scheduler:
            result = json.dumps({"distance": 5 + 2e-7, "unit": "angstrom"})
            with scheduler.db:
                scheduler.db.execute("UPDATE jobs SET result=? WHERE operation_key=?", (result, key))
            control.reconcile(scheduler, key)
            control.observe(scheduler, key)
            self.assertFalse(control.validate(key, "geometry-v2"))
            self.assertTrue(control.validate(key, "geometry-v1"))
            self.assertEqual(control.summary(key)["required_validator"], "geometry-v2")
            self.assertEqual(control.summary(key)["validation"], "REJECTED")
            self.assertFalse(control.summary(key)["accepted"])


if __name__ == "__main__":
    unittest.main()
