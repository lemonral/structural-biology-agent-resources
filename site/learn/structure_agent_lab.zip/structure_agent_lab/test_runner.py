import copy,json,tempfile,unittest
from pathlib import Path
from runner import run,validate

PLAN={'task_id':'toy-01','tool':'distance','unit':'angstrom',
      'points':{'A':[0,0,0],'B':[3,4,0],'C':[0,0,2]},'selection':['A','B']}

class ContractAndGeometryTests(unittest.TestCase):
    def execute(self,plan):
        with tempfile.TemporaryDirectory()as directory:return run(plan,directory)
    def test_known_reference_triangle(self):
        self.assertAlmostEqual(self.execute(PLAN)['value']['distance'],5.0)
    def test_rigid_transform_preserves_internal_distance(self):
        transformed=copy.deepcopy(PLAN)
        transformed['points']={key:[-v[1]+8,v[0]-3,v[2]+11]for key,v in PLAN['points'].items()}
        self.assertAlmostEqual(self.execute(PLAN)['value']['distance'],self.execute(transformed)['value']['distance'])
    def test_selection_order_preserves_distance(self):
        reverse=copy.deepcopy(PLAN);reverse['selection']=['B','A']
        self.assertEqual(self.execute(PLAN)['value'],self.execute(reverse)['value'])
    def test_missing_point_rejected_before_execution(self):
        bad=copy.deepcopy(PLAN);bad['selection']=['A','missing']
        with self.assertRaises(ValueError):validate(bad)
    def test_implicit_units_and_nonfinite_values_rejected(self):
        for change in [{'unit':'nm'},{'points':{'A':[float('nan'),0,0],'B':[3,4,0]}}]:
            bad=copy.deepcopy(PLAN);bad.update(change)
            with self.assertRaises(ValueError):validate(bad)
    def test_execution_is_not_scientific_acceptance(self):
        output=self.execute(PLAN)
        self.assertEqual(output['execution_status'],'completed')
        self.assertEqual(output['scientific_validation'],'not_performed_by_runner')

if __name__=='__main__':unittest.main()
