"""Deterministic tool-contract exercise; no LLM, network, PDB parser or model key."""
import hashlib,json,math,sys
from pathlib import Path

def validate(plan):
    if not isinstance(plan,dict):raise ValueError('plan must be an object')
    required={'task_id','tool','points','selection','unit'}
    if set(plan)!=required:raise ValueError('unexpected or missing fields')
    if not isinstance(plan['task_id'],str)or not plan['task_id']:raise ValueError('task_id required')
    if plan['tool']not in TOOLS:raise ValueError('unknown tool')
    if plan['unit']!='angstrom':raise ValueError('unit must be explicit: angstrom')
    if not isinstance(plan['points'],dict)or not plan['points']:raise ValueError('points required')
    for key,value in plan['points'].items():
        if not isinstance(key,str)or not isinstance(value,list)or len(value)!=3:raise ValueError('invalid point')
        if not all(isinstance(x,(int,float))and not isinstance(x,bool)and math.isfinite(x)for x in value):
            raise ValueError('coordinates must be finite numbers')
    chosen=plan['selection']
    if not isinstance(chosen,list)or not chosen or len(set(chosen))!=len(chosen):raise ValueError('unique selection required')
    if not all(key in plan['points']for key in chosen):raise ValueError('selected point does not exist')
    if plan['tool']=='distance'and len(chosen)!=2:raise ValueError('distance needs two points')
    return plan

def distance(points):
    a,b=points
    return {'distance':math.sqrt(sum((a[i]-b[i])**2 for i in range(3)))}

def centroid(points):
    return {'centroid':[sum(p[i]for p in points)/len(points)for i in range(3)]}

TOOLS={'distance':distance,'centroid':centroid}

def run(plan,outdir):
    validate(plan)
    canonical=json.dumps(plan,sort_keys=True,ensure_ascii=False,allow_nan=False).encode()
    selected=[plan['points'][key]for key in plan['selection']]
    value=TOOLS[plan['tool']](selected)
    result={'task_id':plan['task_id'],'mode':'deterministic_reference','tool':plan['tool'],
            'selection':plan['selection'],'unit':plan['unit'],'input_sha256':hashlib.sha256(canonical).hexdigest(),
            'execution_status':'completed','scientific_validation':'not_performed_by_runner','value':value}
    folder=Path(outdir);folder.mkdir(parents=True,exist_ok=True)
    payload=json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n'
    (folder/'result.json').write_text(payload)
    (folder/'artifact_manifest.json').write_text(json.dumps({'task_id':plan['task_id'],
        'artifact':'result.json','sha256':hashlib.sha256(payload.encode()).hexdigest()},indent=2)+'\n')
    return result

if __name__=='__main__':
    if len(sys.argv)!=3:raise SystemExit('usage: python3 runner.py plan.json output-directory')
    try:
        result=run(json.loads(Path(sys.argv[1]).read_text()),sys.argv[2]);print(json.dumps(result,ensure_ascii=False))
    except (ValueError,KeyError,TypeError)as error:
        print(json.dumps({'execution_status':'rejected','error':str(error)},ensure_ascii=False));raise SystemExit(2)
